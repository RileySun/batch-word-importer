<?php

/*
Plugin Name: Batch Word Importer
Plugin URI: https://github.com/rileysun/batch-word-importer/
Description: Batch Import Word Documents As Posts
Version: 1.4
Author: Riley Lesser
Author URI: https://sun-sys.tk/
*/

include 'meta.php';